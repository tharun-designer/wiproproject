package com.example.nms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.nms.inventory.entity.Device;
import com.example.nms.serviceimpl.InventoryService;

@RestController
@RequestMapping("/api/devices")
public class DeviceController {

	@Autowired
	private InventoryService inventoryService;

	@GetMapping("/get")
	public List<Device> viewAllDevices() {
		return inventoryService.viewAllDevices();
	}

	@PostMapping("/add")
	public Device addDevice(@RequestBody Device device) {
		return inventoryService.addDevice(device);
	}

	@GetMapping("/{id}")
	public Device getDeviceByIdDevice(@PathVariable long id) {
		return inventoryService.viewDeviceById(id).get();
	}

	@GetMapping("/get111")
	public List<Device> viewAllConnectedDevices() {
		return inventoryService.viewAllDevices();
	}
	
	
	
	/*
	 * @DeleteMapping
	 * 
	 * @RequestMapping("/{id}") public ResponseEntity<String>
	 * deleteDevice(@PathVariable long id) { service.deleteDevice(id); return new
	 * ResponseEntity<>("Device deleted", HttpStatus.NO_CONTENT);
	 * 
	 * }
	 */

}
