package com.example.nms.serviceimpl;

import java.util.List;
import java.util.Optional;

import com.example.nms.inventory.entity.Device;

public interface InventoryService {

	public Device addDevice(Device device);

	public Optional<Device> viewDeviceById(long id);

	public List<Device> viewAllDevices();

	public List<Device> viewAllConnectedDevices();

}
