package com.example.nms.wipro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WiproApplicationTests {

	@Test
	void contextLoads() {
	}

}
